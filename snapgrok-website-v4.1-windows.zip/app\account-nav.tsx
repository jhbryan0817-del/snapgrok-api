export function AccountNav() {
  return <a className="nav-account" href="/account">Account</a>;
}
