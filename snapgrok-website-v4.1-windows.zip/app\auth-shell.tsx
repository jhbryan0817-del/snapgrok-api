import type { ReactNode } from "react";

export function AuthShell({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <main className="auth-page">
      <div className="auth-glow" aria-hidden="true" />
      <a className="auth-brand brand" href="/" aria-label="SnapGrok home">
        <img src="/snapgrok-icons/default.png" alt="" />
        <span>SnapGrok</span>
      </a>
      <section className="auth-layout">
        <div className="auth-copy">
          <span className="section-kicker">{eyebrow}</span>
          <h1>{title}</h1>
          <p>{description}</p>
          <div className="auth-assurance">
            <span>01</span>
            <p>Clerk securely handles your identity and session.</p>
            <span>02</span>
            <p>Your xAI and Clerk secret keys never enter the browser.</p>
            <span>03</span>
            <p>Sign in here, then reopen the extension to continue.</p>
          </div>
        </div>
        <div className="clerk-surface">{children}</div>
      </section>
    </main>
  );
}
