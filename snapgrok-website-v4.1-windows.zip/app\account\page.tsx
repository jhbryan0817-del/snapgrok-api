"use client";

import { RedirectToSignIn, Show, UserProfile } from "@clerk/react";

export default function AccountPage() {
  return (
    <main className="account-page">
      <header className="account-header">
        <a className="brand" href="/" aria-label="SnapGrok home">
          <img src="/snapgrok-icons/default.png" alt="" />
          <span>SnapGrok</span>
        </a>
        <a href="/">Back to website</a>
      </header>

      <Show when="signed-out">
        <RedirectToSignIn />
      </Show>

      <Show when="signed-in">
        <section className="account-intro">
          <div>
            <span className="section-kicker">ACCOUNT &amp; SECURITY</span>
            <h1>Manage your SnapGrok account.</h1>
            <p>
              Update your profile, password, connected sign-in methods, and active sessions through Clerk.
            </p>
          </div>
          <aside>
            <span aria-hidden="true">✓</span>
            <div>
              <strong>Extension access is connected</strong>
              <p>Reopen SnapGrok after signing in or changing sessions.</p>
            </div>
          </aside>
        </section>
        <section className="profile-shell" aria-label="SnapGrok account settings">
          <UserProfile routing="hash" />
        </section>
      </Show>
    </main>
  );
}
