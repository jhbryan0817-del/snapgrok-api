"use client";

import { SignUp } from "@clerk/react";
import { AuthShell } from "../auth-shell";

export default function SignUpPage() {
  return (
    <AuthShell
      eyebrow="CREATE YOUR ACCOUNT"
      title="A secure home for your SnapGrok access."
      description="Create an account on the website, then return to the extension. Your authenticated session will sync automatically."
    >
      <SignUp
        routing="hash"
        signInUrl="/sign-in"
        forceRedirectUrl="/account"
        fallbackRedirectUrl="/account"
      />
    </AuthShell>
  );
}
